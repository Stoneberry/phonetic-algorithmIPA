from setuptools import setup
from setuptools import find_packages


setup(name='phonetic_algorithmIPA',
     version='0.1.',
     description='Phonenetic algorithm for IPA',
     author='Anastasiya Kostyanitsyna, George Moroz',
     packages=find_packages(),
     include_package_data=True,
     zip_safe=False
)
