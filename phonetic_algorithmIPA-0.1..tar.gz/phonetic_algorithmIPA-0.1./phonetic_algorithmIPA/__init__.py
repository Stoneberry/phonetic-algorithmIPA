from phonetic_algorithmIPA import phonetic_distance

__all__ = ['phonetic_distance']
